/*
    Write a C program to emulate the ls -l UNIX command that prints all files in a current directory and lists access privileges etc. DO NOT use the exec ls -l from the program.
*/