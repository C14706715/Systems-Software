/*
    Expand the functionality of the program from step 7 to only list specific types. Eg, .c .doc .txt etc. The program also should not display the . and the .. when listing the file names
*/