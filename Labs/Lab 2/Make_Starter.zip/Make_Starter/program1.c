#include <stdio.h>
//#include "newMeesage.h"

int main(int argc, char *argv[]){
    printf("Hello from program 1");
    char s[50] = "\nI live in program_1";
    sayHello(s);
}