#include <stdio.h>

void sayHello(char* message){
    printf("\nMeesage: %s\n", message);
}