#ifndef NEWMESSAGE_H_
#define NEWMESSAGE_H_

void sayHello(char* message);

#endif //AREARECTANGLE_H